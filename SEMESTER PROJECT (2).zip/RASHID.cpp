#include <iostream>
using namespace std;
class Books{
	int select;
	  
 public:
 	 	// BOOKS IN ITCS DEPARTMENT
	void ITCS(){
	cout<<"\t\t\t1.Ethics of Computer\n\n";
	cout<<"\t\t\t2.Information Theory\n\n";
	cout<<"\t\t\t3.C++ Programming\n\n";
	
		}
		// BOOKS IN NATURAL RESOURCES DEPARTMENT	
	void NAR(){
		cout<<"\t\t\t1.Enviromental Science\n\n";
		cout<<"\t\t\t2.Conversation Biology\n\n";
		cout<<"\t\t\t3.Soil Science\n\n";
		 
	}
		 
};
 
	
	 
	 



int main() {
	// arrays for data
 string r_data="data recieve: 12/02/2023";
 string t_data="data return: 12/03/2023";

int chioce,stu_need,department,select;
string user,pass,user1,pass1,student_name,lab;
 
 cout<<"\t\t\t********** RASHID LIBRARY MANAGEMENT SYSTEM*********\n\n";
 restart:
 cout<<"\t\t\t>> PLEASE CHOOSE ANY OPTION\n\n";
cout<<"\t\t\t1.Create an account as a new user\n\n"; 
cout<<"\t\t\t2.student\n\n";
cout<<"\t\t\t3.Librarian\n\n";
cout<<" \t\t\tEnter your choice: ";
cin>>chioce;
if(chioce>3){
	cout<<"\t\t\tEnter correct option\n\n\n";
	goto restart;
	
}
 switch(chioce){
 	case 1:
 		cout<<"\t\t\tEnter user name: ";
 		cin>>user;
 		cout<<"\t\t\tEnter Password: ";
 		cin>>pass;
 		cout<<"\t\t\t Account created successfull\n";
 		 system("\t\t\tpause");
 		 goto restart;  
		  break;
		  
	case 2:	
	   cout<<"\n\t\t\tStudent name: ";
	   cin>>student_name;
	cout<<"\n\n\t\t\t********"<<student_name<<" "<<"WELCOME TO THE SCHOOL  LIBRARY***********\n";
	   cout<<"\n\t\t\t>>Please Choose One Option:\n\n";
	   cout<<"\n\t\t\t1.View BookList\n";
	   cout<<"\n\t\t\t2.search for a Book\n";
 	   cout<<"\n\t\t\t3.close Application\n";
	   cout<<"\n\t\t\tEnter your chioce: ";
	   cin>>stu_need;
	     //NESTED SWITCH
	    switch(stu_need){
	     	case 1:
	     		book:
	     	cout<<"\n\t\t\t*******DEPARTMENT SECTION********\n\n";
	     	cout<<"\n\t\t\t1.ITCS DEPARTMENT\n";
	     	cout<<"\n\t\t\t2.NATURAL RESOURCE DEPARTMENT\n";
 	     	 cout<<"\n\t\t\tSelect Your Department: ";
	     	 cin>>department;
	     	   //IF STATEMENT TO
	     	  if(department==1){
	     	  	 cout<<"\n\n\t\t\t*******LIST OF ITCS BOOKS\n";
	     	  	 Books book;
	     	  	 book.ITCS();
 				  cout<<"\t\t\tSelect the one you like: ";
				 cin>>select;
				 
				 	// STATEMENT FOR SELECTING ETHICS BOOKS
				 	 if(select==1){				 	 	
			cout<<"\t\t\t"<<student_name<<" Ethics of Computer book borrowed\n";
				 	cout<<"\t\t\t"<<r_data<<endl;
				 	cout<<"\t\t\t"<<t_data;
 					  }
					  
						// STATEMENT FOR SELECTING  INFOTHEORY BOOK
					 else if(select==2){
			cout<<"\t\t\t"<<student_name<<" Information Technology book borrowed\n";
					 	cout<<"\t\t\t"<<r_data<<endl;
				 		cout<<"\t\t\t"<<t_data;
 					 }
					 else if(select==3){
			cout<<"\t\t\t"<<student_name<<" C++ book borrowed\n";
					 	cout<<"\t\t\t"<<r_data<<endl;
				 		cout<<"\t\t\t"<<t_data; 
 					 }
					 
					 else{
					 	cout<<"Invalid Option.Try again";
					 	goto book;
					 }	     	  	    
			   }
			   
			       //IF STATEMENT FOR SELECTING FOR NATURAL RESOURCE BOOKS
			    
			   if(department==2){
 			   	cout<<"\n\n\t\t\t*******LIST OF NATURAL RESOURCES BOOKS\n";
			   	Books book;
			   	book.NAR();
			   	
 				cout<<"\t\t\tSelect the one you like: ";
				 cin>>select;
 				// STATEMENT FOR SELECTING NATURAL RESOURCES BOOKS
				 if(select==1){
			cout<<"\t\t\t"<<student_name<<" Enviromental Science book borrowed\n";
				 	cout<<"\t\t\t"<<r_data<<endl;
				 	cout<<"\t\t\t"<<t_data;
 					  }
					  
					 //STATEMENT FOR SELECTING INFO THEORY BOOK
					 else if(select==2){
				cout<<"\t\t\t"<<student_name<<" Conversation Biology book borrowed\n";
					 	cout<<r_data<<endl;
						 cout<<t_data;
						 
					 }
					 
					 //STATEMENT FOR SELECTING C++ BOOK
					 else if(select==3){
				cout<<"\t\t\t"<<student_name<<" Soil Science book borrowed\n";
					 	cout<<r_data<<endl;
					 	cout<<t_data;
 					 }
					 else{
					 	cout<<"Invalid Option.Try again";
					 	goto book;
					 }	     	 			   	 
			   	
				   }
			   	
			   	
			   }
		case 3:
			// LABRARIAN PART
		 	cout<<"\n\t\t\t**********LIBRARIAN ONLY*********\n\n";		  
		 for(int i=0;i<3;++i){
			string lab_pass="password";
			int laboption;
 			cout<<"\n\t\t\tEnter Code: ";
			cin>>lab;
			 
	 	// CHECKING LABRARIAN PASSWORD
 			 if(lab==lab_pass){
  		 cout<<"\t\t\t>> Please choose Any Option \n\n";
			 	cout<<"\t\t\t1.View Books\n\n";
			 	cout<<"\t\t\t2.Add Books\n\n";
			 	cout<<"\t\t\tSelect: ";
			 	cin>>laboption;
			 
		
			    	//LISTING BOOKS FOR LABRARIAN
			 	    switch(laboption){
			 	    	case 1:
			 	    		// ITCS BOOKS LISTED FOR LABRARIAN
			 	    		cout<<"\t\t\tLIST OF ITCS BOOKS\n";
			 	    		cout<<"\t\t\t________________________\n";
			 	    		
			 	    		// NATURAL RESOURCES BOOKS LISTED FOR LABRARIAN
			 	    		 Books book;
			 	    		 book.ITCS();
			 	    		cout<<"\t\t\tLIST OF NATURAL RESOURCES BOOKS\n";
			 	    		cout<<"\t\t\t_________________________________\n";
 			 	    		book.NAR();
 			 	    		break;
 			 	    	
 			 	        case 2:
 			 	        	
 			 	        	// LABRIAN SELCTING DEPARTEMENT TO ADD BOOK
 			 	           int depart;
 			 	            depart:
 			 	            cout<<"\t\t\t1.ITCS DEPARTEMENT\n\n";
 			 	            cout<<"\t\t\t2.NATURAL RESOURCES DEPARTEMENT\n\n";
 			 	        	cout<<"\t\t\tSelect Department: ";
 			 	        	cin>>depart;
 			 	        	 	if(depart==1){
							//ADD BOOK FOR ITCS DEPARTMENT	   
 							  string author,bookname,bookid;
							 	cout<<"\t\t\tBook name: ";
							 	cin>>bookname;
							 	cout<<"\t\t\tAuthors name: ";
							 	cin>>author;
							 	cout<<"\t\t\tBook ID: ";
							 	cin>>bookid;
 			   cout<<"\t\t\t"<<bookname<<" has been added to ITCS department books successfully";
 			   		break;
 			   }        	
 			   				//ADD BOOK TO NATURAL RESOURCES 
 			   		       else if(depart==2){
							     string author,bookname,bookid;
 			   		            cout<<"\t\t\tBook name: ";
							 	cin>>bookname;
							 	cout<<"\t\t\tAuthors name: ";
							 	cin>>author;
							 	cout<<"\t\t\tBook ID: ";
							 	cin>>bookid;
 			   cout<<"\t\t\t"<<bookname<<" has been added to Natural Resources department books successfully";
 			   		break;
 			   	}
 			   	
 			   	
 			   	else{
 			   		cout<<"Invalid Option";
 			   		 goto depart;
					}
								
			}
			  
		 
	}
	else{
		cout<<"\t\t\tIncorrect Password.Try again\n";
	}
}
 // ACCOUNT BLOCKED MESSAGE
  cout<<"\t\t\tAccoutBloced";
 
			  
	}
		return 0;
	}


					 
	  
 
    

 
 	


